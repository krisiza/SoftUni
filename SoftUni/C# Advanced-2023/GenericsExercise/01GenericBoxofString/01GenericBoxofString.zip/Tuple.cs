﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01GenericBoxofString
{
    public class Tuple
    {
        public object FirstProperty { get; set; }

        public object SecondProperty { get; set; }       
        
        public object ThirdProperty { get; set; }
    }    
}
