﻿using _3.Raiding.IO.Interfaces;

namespace _3.Raiding.IO
{
    public class Reader : IReader
    {
        public string ReadLine()
            => Console.ReadLine();
    }
}
