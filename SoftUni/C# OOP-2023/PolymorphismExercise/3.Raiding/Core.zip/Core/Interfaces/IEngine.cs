﻿
namespace _3.Raiding.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
